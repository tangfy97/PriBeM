package toyForTest;

import java.util.Scanner;

public class data {
	
	int getter() {
		try (Scanner keyboard = new Scanner(System.in)) {
			System.out.println("Enter an integer: ");
			return keyboard.nextInt();
		}
	}
}
	
